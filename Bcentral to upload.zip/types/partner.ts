export interface Partner {
  src: string;
  width: number;
  height: number;
  href?: string;
}
