export interface Expertise {
  title: string;
  num: string;
  hoverImage: string;
  mainImage: string;
}
