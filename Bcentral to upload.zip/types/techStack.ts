export interface Techstack {
  name: string;
  icon: string;
}
