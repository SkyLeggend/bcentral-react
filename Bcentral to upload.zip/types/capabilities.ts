export interface compatibility {
  title: string;
  num: string;
  hoverImage: string;
  mainImage: string;
}
